﻿using System;
using System.Collections.Generic;
using System.Text;
using static GoogleHashCode2020.GlovalVar;

namespace GoogleHashCode2020
{
    static class BruteFQ
    {
        public static void main()
        {
            bool[] usedBooks = new bool[nBooks];

        }
    }
}

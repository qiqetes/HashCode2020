﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GoogleHashCode2020
{
    public static class GlovalVar
    {

        ///////////////////////   GLOBAL VARIABLES   /////////////////////
        public static int nBooks; // number of books
        public static int nLibraries; // number of libraries
        public static int nDays; // days we have to scan
        public static Book[] books = null;
        public static Library[] libraries = null;
        /////////////////////////////////////////////////////////////////

    }
}
